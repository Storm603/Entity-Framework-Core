﻿using SoftUni.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Runtime.InteropServices;
using System.Text;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Query;
using SoftUni.Models;

namespace SoftUni
{
    public class StartUp
    {
        static void Main(string[] args)
        {   
            SoftUniContext context = new SoftUniContext();

            string output = GetLatestProjects(context);

            Console.WriteLine(output);

        }

        public static string GetLatestProjects(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();

            var info = context.Projects.Select(e => new
                {
                    EndDate = e.EndDate,
                    Name = e.Name,
                    Description = e.Description,
                    StartDate = e.StartDate
                }).Where(e => e.EndDate == null).OrderByDescending(d => d.StartDate)
                .Take(10).ToArray();

            foreach (var item in info.OrderBy(n => n.Name))
            {
                sb.AppendLine($"{item.Name}");
                sb.AppendLine($"{item.Description}");
                sb.AppendLine($"{item.StartDate:M/d/yyyy h:mm:ss tt}");
            }

            return sb.ToString().Trim();
        }

        //public static string GetDepartmentsWithMoreThan5Employees(SoftUniContext context)
        //{
        //    StringBuilder sb = new StringBuilder();

        //    var info = context.Departments.Include(e => e.Employees)
        //        .Select(e => new
        //        {
        //            DepartmentName = e.Name,
        //            ManagerName = e.Manager.FirstName + " " + e.Manager.LastName,
        //            EmployeeCollection = e.Employees
        //        }).Where(ec => ec.EmployeeCollection.Count > 5).OrderBy(ec => ec.EmployeeCollection.Count)
        //        .ThenBy(dn => dn.DepartmentName).ToArray();

        //    foreach (var dep in info)
        //    {
        //        sb.AppendLine($"{dep.DepartmentName} - {dep.ManagerName}");

        //        foreach (Employee employee in dep.EmployeeCollection.OrderBy(e => e.FirstName).ThenBy(e => e.LastName))
        //        {
        //            sb.AppendLine($"{employee.FirstName} {employee.LastName} - {employee.JobTitle}");
        //        }
        //    }

        //    return sb.ToString().Trim();
        //}

        //public static string GetEmployee147(SoftUniContext context)
        //{
        //    StringBuilder sb = new StringBuilder();

        //    var info = context.Employees.Include(p => p.EmployeesProjects)
        //        .Select(e => new
        //        {
        //            e.EmployeeId,
        //            e.FirstName,
        //            e.LastName,
        //            e.JobTitle,
        //            coll = e.EmployeesProjects.Select(p => p.Project.Name)
        //        }).Where(e => e.EmployeeId == 147).ToArray();

        //    foreach (var item in info)
        //    {
        //        sb.AppendLine($"{item.FirstName} {item.LastName} - {item.JobTitle}");

        //        foreach (var item2 in item.coll.OrderBy(n => n))
        //        {
        //            sb.AppendLine(item2);
        //        }
        //    }

        //    return sb.ToString().Trim();
        //}

        //public static string GetAddressesByTown(SoftUniContext context)
        //{
        //    StringBuilder sb = new StringBuilder();

        //    var coll = context.Addresses.Include(b => b.Employees)
        //        .Select(a => new
        //        {
        //            AddressName = a.AddressText,
        //            TownName = a.Town.Name,
        //            EmployeeCount = a.Employees.Count()

        //        }).OrderByDescending(b => b.EmployeeCount).ThenBy(b => b.TownName).ThenBy(b => b.AddressName).Take(10)
        //        .ToArray();

        //    foreach (var item in coll)
        //    {
        //        sb.AppendLine($"{item.AddressName}, {item.TownName} - {item.EmployeeCount} employees");
        //    }

        //    return sb.ToString().Trim();
        //}

        //public static string GetEmployeesInPeriod(SoftUniContext context)
        //{
        //    StringBuilder sb = new StringBuilder();
           
        //    var info = context
        //        .Employees
        //        .Where(e => e.EmployeesProjects.Any(ep => ep.Project.StartDate.Year >= 2001 && ep.Project.StartDate.Year <= 2003))
        //        .Take(10)
        //        .Select(e => new
        //        {
        //            e.FirstName,
        //            e.LastName,
        //            ManagerFirstName = e.Manager.FirstName,
        //            ManagerLastName = e.Manager.LastName,
        //            EmployeeProjects = e.EmployeesProjects.Select(ep => new
        //            {
        //                ep.Project.Name,
        //                ProjectStartDate = ep.Project.StartDate.ToString("M/d/yyyy h:mm:ss tt"),
        //                ProjectEndDate = ep.Project.EndDate == null ? "not finished" : ep.Project.EndDate.Value.ToString("M/d/yyyy h:mm:ss tt")
        //            }).ToArray()

        //        }).ToArray();

            
        //    foreach (var item in info)
        //    {
        //        sb.AppendLine($"{item.FirstName} {item.LastName} - Manager: {item.ManagerFirstName} {item.ManagerLastName}");
        //        foreach (var employeeProject in item.EmployeeProjects)
        //        {
        //            sb.AppendLine($"--{employeeProject.Name} - {employeeProject.ProjectStartDate} - {employeeProject.ProjectEndDate}");
        //        }
        //    }




        //    return sb.ToString().Trim();
        //}
    }
}
