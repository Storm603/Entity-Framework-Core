﻿using SoftUni.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Runtime.InteropServices;
using System.Text;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Query;
using SoftUni.Models;

namespace SoftUni
{
    public class StartUp
    {
        static void Main(string[] args)
        {   
            SoftUniContext context = new SoftUniContext();

            string output = GetEmployeesInPeriod(context);

            Console.WriteLine(output);

        }

        public static string GetEmployeesInPeriod(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();
           
            var info = context
                .Employees
                .Where(e => e.EmployeesProjects.Any(ep => ep.Project.StartDate.Year >= 2001 && ep.Project.StartDate.Year <= 2003))
                .Take(10)
                .Select(e => new
                {
                    e.FirstName,
                    e.LastName,
                    ManagerFirstName = e.Manager.FirstName,
                    ManagerLastName = e.Manager.LastName,
                    EmployeeProjects = e.EmployeesProjects.Select(ep => new
                    {
                        ep.Project.Name,
                        ProjectStartDate = ep.Project.StartDate.ToString("M/d/yyyy h:mm:ss tt"),
                        ProjectEndDate = ep.Project.EndDate == null ? "not finished" : ep.Project.EndDate.Value.ToString("M/d/yyyy h:mm:ss tt")
                    }).ToArray()

                }).ToArray();

            
            foreach (var item in info)
            {
                sb.AppendLine($"{item.FirstName} {item.LastName} - Manager: {item.ManagerFirstName} {item.ManagerLastName}");
                foreach (var employeeProject in item.EmployeeProjects)
                {
                    sb.AppendLine($"--{employeeProject.Name} - {employeeProject.ProjectStartDate} - {employeeProject.ProjectEndDate}");
                }
            }




            return sb.ToString().Trim();
        }
    }
}
