﻿using SoftUni.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;

namespace SoftUni
{
    public class StartUp
    {
        static void Main(string[] args)
        {   
            SoftUniContext context = new SoftUniContext();

            string info = GetEmployeesFullInformation(context);

            Console.WriteLine(info);
        }

        public static string GetEmployeesFullInformation(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();

            var records = context.Employees
                .Select(e => new
                {
                    e.EmployeeId,
                    e.FirstName,
                    e.LastName,
                    e.MiddleName,
                    e.JobTitle,
                    e.Salary
                }).ToArray().OrderBy(e => e.EmployeeId);

            foreach (var @record in records)
            {
                sb.AppendLine(
                    $"{record.FirstName} {record.LastName} {record.MiddleName} {record.JobTitle} {record.Salary:f2}");
                
            }

            return sb.ToString().Trim();
        }
    }
}
