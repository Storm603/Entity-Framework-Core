﻿using SoftUni.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using SoftUni.Models;

namespace SoftUni
{
    public class StartUp
    {
        static void Main(string[] args)
        {   
            SoftUniContext context = new SoftUniContext();

            string output = GetEmployeesWithSalaryOver50000(context);

            Console.WriteLine(output);

        }

        public static string GetEmployeesWithSalaryOver50000(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();
            
            var result = context.Employees.Select(e => new
            {
                e.FirstName,
                e.Salary
            }).Where(e => e.Salary > 50000).OrderBy(e => e.FirstName).ToArray();

            foreach (var item in result)
            {
                sb.AppendLine($"{item.FirstName} - {item.Salary:f2}");
            }

            return sb.ToString().Trim();
        }
    }
}
