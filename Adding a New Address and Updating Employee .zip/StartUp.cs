﻿using SoftUni.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Query;
using SoftUni.Models;

namespace SoftUni
{
    public class StartUp
    {
        static void Main(string[] args)
        {   
            SoftUniContext context = new SoftUniContext();

            string output = AddNewAddressToEmployee(context);

            Console.WriteLine(output);

        }

        public static string AddNewAddressToEmployee(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();

            Address addr = new Address() {AddressText = "Vitoshka 15", TownId = 4};

            Employee emp = context.Employees.Where(e => e.LastName == "Nakov").First();

            emp.Address = addr;

            context.SaveChanges();

            var empColl = context.Employees.Include(x => x.Address)
                .Select(e => new{e.Address.AddressText, e.AddressId}).OrderByDescending(e => e.AddressId).Take(10).ToArray();

            foreach (var VARIABLE in empColl)
            {
                sb.AppendLine(VARIABLE.AddressText);
            }

            return sb.ToString().Trim();
        }
    }
}
