﻿using SoftUni.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Query;
using SoftUni.Models;

namespace SoftUni
{
    public class StartUp
    {
        static void Main(string[] args)
        {   
            SoftUniContext context = new SoftUniContext();

            string output = GetEmployeesFromResearchAndDevelopment(context);

            Console.WriteLine(output);

        }

        public static string GetEmployeesFromResearchAndDevelopment(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();

            var employeeColl = context.Employees.Select(e => new
            {
                e.FirstName,
                e.LastName,
                e.Salary, e.Department
            }).Where(e => e.Department.Name == "Research and Development").OrderBy(e => e.Salary)
                .ThenByDescending(e => e.FirstName).ToArray();

            foreach (var item in employeeColl)
            {
                sb.AppendLine($"{item.FirstName} {item.LastName} from {item.Department.Name} - ${item.Salary:f2}");
            }

            return sb.ToString().TrimEnd();
        }
    }
}
